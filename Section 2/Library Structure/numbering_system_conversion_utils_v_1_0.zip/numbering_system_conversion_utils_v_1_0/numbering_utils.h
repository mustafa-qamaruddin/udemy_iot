#ifndef _NUMBERING_UTILS_H
#define _NUMBERING_UTILS_H

#include <Arduino.h>

class NumberingUtils {
  public:
    NumberingUtils() {

    }

    static String decimal2binary(unsigned long);
};

#endif _NUMBERING_UTILS_H
